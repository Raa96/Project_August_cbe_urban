import streamlit as st
import pandas as pd
import plotly.express as px
import json
import streamlit.components.v1 as components
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db
import styles as sy

st.set_page_config(page_title="Spatial Explorer — CUI", layout="wide")
sy.inject_custom_css()
sy.page_header(
    "Spatial Explorer",
    "> Unified telemetry + OpenStreetMap overlay — traffic, AQI, civic hotspots, and infrastructure POIs.",
    "SPATIAL MODULE // LIVE",
)
sy.ticker([
    "> Loading spatial vectors...",
    "> Telemetry grid synced.",
    "> 853 OSM POIs loaded.",
    "> Density matrix ready.",
])

CHART_LAYOUT = dict(
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(2,6,23,0.6)',
    font=dict(family='Fira Code, monospace', color='#94a3b8', size=11),
    margin=dict(l=12, r=12, t=36, b=12),
    xaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    yaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    legend=dict(bgcolor='rgba(15,23,42,0.6)', bordercolor='#334155', borderwidth=1),
)

# ─── Data ──────────────────────────────────────────────────────────────────────
df_areas = db.get_areas()
df_traffic_avg = db.get_traffic().groupby('area')['vehicle_count'].mean().reset_index()
df_aq_avg = db.get_air_quality().groupby('area')['pm25'].mean().reset_index()
df_civic = db.get_civic_issues()
df_osm = db.get_osm_infrastructure()
total_osm = len(df_osm)
cat_counts = df_osm.groupby('category').size().to_dict()

CAT_COLORS = {
    "hospitals": "#f43f5e",
    "schools": "#22d3ee",
    "traffic_nodes": "#f59e0b",
    "pharmacies": "#a855f7",
    "parks": "#34d399",
}
CAT_LABELS = {
    "hospitals": "Hospitals", "schools": "Schools", "traffic_nodes": "Traffic",
    "pharmacies": "Pharmacies", "parks": "Parks",
}

# Build telemetry payloads
df_map = df_areas.merge(df_traffic_avg, on='area').merge(df_aq_avg, on='area')

traffic_json = []
for _, r in df_map.iterrows():
    traffic_json.append({
        "lat": r["latitude"], "lon": r["longitude"], "name": r["area"],
        "type": r["area_type"], "zone": r["zone"],
        "traffic": round(float(r["vehicle_count"]), 1),
        "aqi": round(float(r["pm25"]), 1),
    })

civic_counts = df_civic.groupby('area').size().reset_index(name='count')
civic_map = df_areas.merge(civic_counts, on='area', how='left').fillna(0)
civic_json = []
for _, r in civic_map.iterrows():
    civic_json.append({
        "lat": r["latitude"], "lon": r["longitude"], "name": r["area"],
        "complaints": int(r["count"])
    })

aq_json = []
for _, r in df_map.iterrows():
    aq_json.append({
        "lat": r["latitude"], "lon": r["longitude"], "name": r["area"],
        "aqi": round(float(r["pm25"]), 1), "type": r["area_type"]
    })

def markers_for(records, cat):
    return [
        {"lat": r["lat"], "lon": r["lon"], "name": r["name"],
         "area": r["area"], "dist": float(r["distance_to_area_km"] or 0)}
        for _, r in records.iterrows()
    ]

js_layers = {}
for cat in CAT_COLORS:
    js_layers[cat] = json.dumps(markers_for(df_osm[df_osm['category'] == cat], cat))

traffic_js = json.dumps(traffic_json)
civic_js   = json.dumps(civic_json)
aq_js      = json.dumps(aq_json)

# ─── Panel rows ────────────────────────────────────────────────────────────────
telemetry_rows = f"""
    <div class="layer-row" onclick="toggle('traffic')">
      <div class="layer-info">
        <div class="layer-dot" style="background:#f43f5e; box-shadow: 0 0 6px #f43f5e88;"></div>
        <div><div class="layer-name">Traffic Nodes</div><div class="layer-count">{len(traffic_json)} zones</div></div>
      </div>
      <div class="toggle on" id="tog-traffic"></div>
    </div>
    <div class="layer-row" onclick="toggle('aqi')">
      <div class="layer-info">
        <div class="layer-dot" style="background:#22d3ee; box-shadow: 0 0 6px #22d3ee88;"></div>
        <div><div class="layer-name">AQI Stations</div><div class="layer-count">{len(aq_json)} monitors</div></div>
      </div>
      <div class="toggle on" id="tog-aqi"></div>
    </div>
    <div class="layer-row" onclick="toggle('civic')">
      <div class="layer-info">
        <div class="layer-dot" style="background:#a855f7; box-shadow: 0 0 6px #a855f788;"></div>
        <div><div class="layer-name">Civic Hotspots</div><div class="layer-count">complaint zones</div></div>
      </div>
      <div class="toggle on" id="tog-civic"></div>
    </div>
    <div class="divider"></div>
    <div class="heatmap-row">
      <div><div class="heatmap-label">Congestion Heatmap</div></div>
      <div class="toggle on" id="tog-heat" onclick="toggle('heat')"></div>
    </div>
    <div class="heatmap-gradient"></div>
    <div class="heatmap-labels"><span>Low</span><span>High Density</span></div>
    <div class="divider"></div>
"""

osm_rows = ""
for cat, color in CAT_COLORS.items():
    osm_rows += f"""
        <div class="layer-row" onclick="toggle('{cat}')">
          <div class="layer-info">
            <div class="layer-dot" style="background:{color}; box-shadow: 0 0 6px {color}88;"></div>
            <div><div class="layer-name">{CAT_LABELS[cat]}</div><div class="layer-count">{cat_counts.get(cat, 0)} POIs</div></div>
          </div>
          <div class="toggle on" id="tog-{cat}"></div>
        </div>
    """

leaflet_html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.heat/0.2.0/leaflet-heat.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500&family=Fira+Sans:wght@400;500&display=swap" rel="stylesheet"/>

  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ background: #020617; font-family: 'Fira Sans', sans-serif; color: #cbd5e1; height: 100vh; display: flex; flex-direction: column; }}
    ::-webkit-scrollbar {{ width: 5px; }}
    ::-webkit-scrollbar-track {{ background: #020617; }}
    ::-webkit-scrollbar-thumb {{ background: #334155; border-radius: 3px; }}
    .leaflet-container {{ background: #020617; outline: none; }}
    .leaflet-bar a {{ background-color: #0f172a !important; color: #94a3b8 !important; border-bottom-color: #1e293b !important; }}
    .leaflet-bar a:hover {{ background-color: #1e293b !important; color: #22d3ee !important; }}
    .leaflet-popup-content-wrapper {{ background-color: #0f172a; color: #f8fafc; border: 1px solid #334155; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.8); padding: 0; }}
    .leaflet-popup-content {{ margin: 12px 14px; font-family: 'Fira Sans', sans-serif; }}
    .leaflet-popup-tip {{ background: #0f172a; }}
    .leaflet-attribution-flag {{ display: none !important; }}
    #map {{ flex: 1; z-index: 1; }}
    .panel {{
      position: absolute; top: 12px; right: 12px; z-index: 1000;
      background: rgba(15, 23, 42, 0.9); backdrop-filter: blur(12px);
      border: 1px solid #334155; border-radius: 10px; padding: 14px 16px;
      width: 220px; max-height: calc(100vh - 40px); overflow-y: auto;
    }}
    .panel-title {{
      font-family: 'Fira Code', monospace; font-size: 9px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.12em; color: #64748b;
      margin-bottom: 12px; border-bottom: 1px solid #1e293b; padding-bottom: 8px;
    }}
    .layer-row {{ display: flex; align-items: center; justify-content: space-between; padding: 6px 0; cursor: pointer; }}
    .layer-info {{ display: flex; align-items: center; gap: 8px; }}
    .layer-dot {{ width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }}
    .layer-name {{ font-size: 12px; font-weight: 500; color: #cbd5e1; }}
    .layer-count {{ font-family: 'Fira Code', monospace; font-size: 9px; color: #64748b; }}
    .toggle {{ width: 32px; height: 17px; background: #22d3ee; border-radius: 9px; position: relative; cursor: pointer; transition: background 0.2s; }}
    .toggle.off {{ background: #334155; }}
    .toggle::after {{ content: ''; position: absolute; top: 2px; left: 2px; width: 13px; height: 13px; background: white; border-radius: 50%; transition: transform 0.2s; }}
    .toggle.on::after {{ transform: translateX(15px); }}
    .divider {{ height: 1px; background: #1e293b; margin: 10px 0; }}
    .heatmap-row {{ display: flex; align-items: center; justify-content: space-between; padding: 6px 0; }}
    .heatmap-label {{ font-family: 'Fira Code', monospace; font-size: 11px; font-weight: 700; color: #f59e0b; }}
    .heatmap-gradient {{ height: 6px; width: 100%; border-radius: 3px; background: linear-gradient(to right, #3b82f6, #f59e0b, #f43f5e); margin-top: 8px; }}
    .heatmap-labels {{ display: flex; justify-content: space-between; font-family: 'Fira Code', monospace; font-size: 8px; color: #64748b; text-transform: uppercase; margin-top: 4px; }}
    .statusbar {{
      position: absolute; bottom: 10px; left: 12px; z-index: 1000;
      display: flex; align-items: center; gap: 8px;
      background: rgba(15,23,42,0.88); backdrop-filter: blur(8px);
      border: 1px solid #1e293b; border-radius: 6px; padding: 6px 12px;
      font-family: 'Fira Code', monospace; font-size: 10px; color: #22d3ee;
    }}
    .status-dot {{ width: 7px; height: 7px; border-radius: 50%; background: #22d3ee; animation: pulse 2s infinite; }}
    @keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.3; }} }}
  </style>
</head>
<body>

<div id="map"></div>

<div class="panel">
  <div class="panel-title">// Overlay Vectors</div>
  {telemetry_rows}
  <div class="panel-title" style="margin-top:12px;">// OSM Infrastructure</div>
  {osm_rows}
</div>

<div class="statusbar">
  <div class="status-dot"></div>
  SYS.ONLINE // Coimbatore, Tamil Nadu // {len(traffic_json)} Nodes + {total_osm} POIs Loaded
</div>

<script>
  const TRAFFIC_DATA = {traffic_js};
  const CIVIC_DATA   = {civic_js};
  const AQI_DATA     = {aq_js};
  const LAYERS       = {{
    {','.join(f'"{cat}": {js_layers[cat]}' for cat in CAT_COLORS)}
  }};
  const COLORS       = {json.dumps(CAT_COLORS)};

  const map = L.map("map", {{ center: [11.0168, 76.9558], zoom: 13, zoomControl: false }});
  L.control.zoom({{ position: "bottomright" }}).addTo(map);
  L.tileLayer("https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png", {{
    attribution: "© OpenStreetMap contributors, © CartoDB", maxZoom: 19, subdomains: "abcd"
  }}).addTo(map);

  const LG = {{
    traffic: L.layerGroup().addTo(map),
    aqi:     L.layerGroup().addTo(map),
    civic:   L.layerGroup().addTo(map),
    heat:    null,
  }};
  const LA = {{ traffic: true, aqi: true, civic: true, heat: true }};

  Object.keys(LAYERS).forEach(cat => {{
    LG[cat] = L.layerGroup().addTo(map);
    LA[cat] = true;
  }});

  function trafficPopup(d) {{
    const level = d.traffic > 600 ? "HIGH" : d.traffic > 400 ? "MEDIUM" : "LOW";
    const color = d.traffic > 600 ? "#f43f5e" : d.traffic > 400 ? "#f59e0b" : "#22d3ee";
    return `
      <div style="padding:8px 4px;min-width:200px;">
        <div style="font-family:'Fira Code',monospace;font-weight:600;color:#f8fafc;font-size:13px;margin-bottom:6px;">${{d.name}}</div>
        <span style="font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;background:${{color}}22;color:${{color}};padding:2px 6px;border-radius:4px;border:1px solid ${{color}}44;">${{level}} TRAFFIC</span>
        <div style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px;">
          <div><div style="color:#64748b;font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;">Avg Vehicles/hr</div><div style="color:#f8fafc;font-weight:600;font-family:'Fira Code',monospace;">${{d.traffic}}</div></div>
          <div><div style="color:#64748b;font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;">PM2.5 AQI</div><div style="color:#22d3ee;font-weight:600;font-family:'Fira Code',monospace;">${{d.aqi}} µg/m³</div></div>
        </div>
        <div style="color:#64748b;font-size:10px;margin-top:8px;font-family:'Fira Code',monospace;">${{d.zone}} Zone · ${{d.type}}</div>
      </div>`;
  }}

  function aqiPopup(d) {{
    const level = d.aqi > 50 ? "MODERATE" : d.aqi > 25 ? "SATISFACTORY" : "GOOD";
    const color = d.aqi > 50 ? "#f59e0b" : d.aqi > 25 ? "#22d3ee" : "#34d399";
    return `
      <div style="padding:8px 4px;min-width:200px;">
        <div style="font-family:'Fira Code',monospace;font-weight:600;color:#f8fafc;font-size:13px;margin-bottom:6px;">${{d.name}}</div>
        <span style="font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;background:${{color}}22;color:${{color}};padding:2px 6px;border-radius:4px;border:1px solid ${{color}}44;">AQI ${{level}}</span>
        <div style="margin-top:10px;font-size:11px;">
          <div><div style="color:#64748b;font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;">PM2.5 Concentration</div><div style="color:${{color}};font-weight:700;font-family:'Fira Code',monospace;font-size:18px;">${{d.aqi}} µg/m³</div></div>
        </div>
      </div>`;
  }}

  function civicPopup(d) {{
    const color = d.complaints > 5 ? "#f43f5e" : d.complaints > 3 ? "#f59e0b" : "#a855f7";
    return `
      <div style="padding:8px 4px;min-width:200px;">
        <div style="font-family:'Fira Code',monospace;font-weight:600;color:#f8fafc;font-size:13px;margin-bottom:6px;">${{d.name}}</div>
        <span style="font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;background:${{color}}22;color:${{color}};padding:2px 6px;border-radius:4px;border:1px solid ${{color}}44;">CIVIC ZONE</span>
        <div style="margin-top:10px;font-size:11px;">
          <div><div style="color:#64748b;font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;">Filed Complaints</div><div style="color:${{color}};font-weight:700;font-family:'Fira Code',monospace;font-size:22px;">${{d.complaints}}</div></div>
        </div>
      </div>`;
  }}

  function osmPopup(d, cat) {{
    const label = (cat.replace('_',' ')).toUpperCase();
    const color = COLORS[cat];
    return `
      <div style="padding:8px 4px;min-width:180px;">
        <div style="font-family:'Fira Code',monospace;font-weight:600;color:#f8fafc;font-size:13px;margin-bottom:6px;">${{d.name}}</div>
        <span style="font-family:'Fira Code',monospace;font-size:9px;text-transform:uppercase;background:${{color}}22;color:${{color}};padding:2px 6px;border-radius:4px;border:1px solid ${{color}}44;">${{label}}</span>
        <div style="color:#94a3b8;font-size:11px;margin-top:8px;">Nearest Node: <b style="color:#f8fafc;">${{d.area}}</b></div>
      </div>`;
  }}

  TRAFFIC_DATA.forEach(d => {{
    const radius = Math.max(6, Math.min(18, d.traffic / 60));
    L.circleMarker([d.lat, d.lon], {{
      radius, fillColor: "#f43f5e", color: "#0f172a",
      weight: 1, opacity: 1, fillOpacity: 0.85,
    }}).bindPopup(trafficPopup(d), {{ maxWidth: 260 }}).addTo(LG.traffic);
  }});

  AQI_DATA.forEach(d => {{
    const radius = Math.max(5, Math.min(14, d.aqi / 4));
    L.circleMarker([d.lat, d.lon], {{
      radius, fillColor: "#22d3ee", color: "#0f172a",
      weight: 1, opacity: 1, fillOpacity: 0.8,
    }}).bindPopup(aqiPopup(d), {{ maxWidth: 260 }}).addTo(LG.aqi);
  }});

  CIVIC_DATA.forEach(d => {{
    if (d.complaints === 0) return;
    const radius = Math.max(5, Math.min(16, d.complaints * 2));
    L.circleMarker([d.lat, d.lon], {{
      radius, fillColor: "#a855f7", color: "#0f172a",
      weight: 1, opacity: 1, fillOpacity: 0.75,
    }}).bindPopup(civicPopup(d), {{ maxWidth: 260 }}).addTo(LG.civic);
  }});

  Object.keys(LAYERS).forEach(cat => {{
    LAYERS[cat].forEach(d => {{
      const radius = Math.max(5, Math.min(14, 1000 / (d.dist || 1) / 25));
      L.circleMarker([d.lat, d.lon], {{
        radius, fillColor: COLORS[cat], color: "#0f172a",
        weight: 1, opacity: 1, fillOpacity: 0.8
      }}).bindPopup(osmPopup(d, cat), {{ maxWidth: 240 }}).addTo(LG[cat]);
    }});
  }});

  const heatPoints = TRAFFIC_DATA.map(d => [d.lat, d.lon, d.traffic / 1000]);
  LG.heat = L.heatLayer(heatPoints, {{
    radius: 40, blur: 30, maxZoom: 14,
    gradient: {{ 0.2: "#3b82f6", 0.5: "#f59e0b", 1.0: "#f43f5e" }}
  }}).addTo(map);

  function toggle(name) {{
    LA[name] = !LA[name];
    const tog = document.getElementById(`tog-${{name}}`);
    if (tog) tog.className = "toggle " + (LA[name] ? "on" : "off");
    if (LG[name]) LA[name] ? map.addLayer(LG[name]) : map.removeLayer(LG[name]);
  }}
</script>
</body>
</html>
"""

components.html(leaflet_html, height=600, scrolling=False)

# ─── OSM Density Charts ────────────────────────────────────────────────────────
if not df_osm.empty:
    st.markdown('<div class="section-label" style="margin-top:2rem;">Infrastructure Density</div>', unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="section-label">POI Category Distribution</div>', unsafe_allow_html=True)
        df_cat = df_osm.groupby('category').size().reset_index(name='count')
        fig = px.bar(
            df_cat, x='count', y='category', orientation='h',
            color='category', color_discrete_map=CAT_COLORS,
            labels={'count': 'POI Count', 'category': 'Category'},
        )
        fig.update_layout(**CHART_LAYOUT)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown('<div class="section-label">Infrastructure by Area Node</div>', unsafe_allow_html=True)
        df_area = df_osm.groupby(['area', 'category']).size().reset_index(name='count')
        fig2 = px.bar(
            df_area, x='area', y='count', color='category',
            color_discrete_map=CAT_COLORS,
            barmode='stack', labels={'count': 'POI Count', 'area': 'Area'},
        )
        fig2.update_layout(**CHART_LAYOUT, xaxis_tickangle=-35)
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('<div class="section-label">Category × Area Density Matrix</div>', unsafe_allow_html=True)
    pivot = df_osm.pivot_table(index='area', columns='category', values='osm_id',
                               aggfunc='count').fillna(0)
    for cat in CAT_COLORS:
        if cat not in pivot.columns:
            pivot[cat] = 0
    pivot = pivot[list(CAT_COLORS.keys())]
    fig3 = px.imshow(
        pivot, text_auto=True, aspect='auto',
        color_continuous_scale=[[0, '#0f172a'], [0.5, '#3b82f6'], [1, '#22d3ee']],
        labels={'color': 'POI Count'},
    )
    fig3.update_layout(**CHART_LAYOUT)
    st.plotly_chart(fig3, use_container_width=True)

    st.markdown('<div class="section-label" style="margin-top:1rem;">POI Registry</div>', unsafe_allow_html=True)
    st.dataframe(
        df_osm[['name', 'category', 'area', 'distance_to_area_km', 'lat', 'lon']]
            .rename(columns={'distance_to_area_km': 'dist(km)'}),
        use_container_width=True, hide_index=True,
    )

    csv = df_osm.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="EXPORT POI CSV",
        data=csv,
        file_name="osm_coimbatore_pois.csv",
        mime='text/csv',
    )

sy.footer()