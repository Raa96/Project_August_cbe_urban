import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db
import styles as sy

st.set_page_config(page_title="Air & Water Pollution — CUI", layout="wide")
sy.inject_custom_css()
sy.page_header(
    "Air & Water Pollution Monitoring",
    "> Ambient pollutants, IMD climate normals, historical CPCB AQI, and rainfall extremes.",
    "ENVIRONMENT MODULE // ACTIVE",
)
sy.ticker([
    "> Fetching AQI telemetry...",
    "> Pollutant vectors loaded.",
    "> IMD normals synced.",
    "> Historical AQI computed.",
])

CHART_LAYOUT = dict(
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(2,6,23,0.6)',
    font=dict(family='Fira Code, monospace', color='#94a3b8', size=11),
    margin=dict(l=12, r=12, t=36, b=12),
    xaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    yaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    legend=dict(bgcolor='rgba(15,23,42,0.6)', bordercolor='#334155', borderwidth=1),
)

areas_list = ["All"] + list(db.get_areas()['area'].unique())
st.sidebar.markdown('<p style="font-family:\'Fira Code\',monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#64748b;margin-bottom:8px;">// Env Filter</p>', unsafe_allow_html=True)
selected_area = st.sidebar.selectbox("Env Area Node", areas_list)

area_filter = None if selected_area == "All" else selected_area
df_aq = db.get_air_quality(area=area_filter)
df_wx = db.get_weather()
df_wx['date'] = pd.to_datetime(df_wx['date'])

if df_aq.empty:
    st.warning("No environmental data found.")
else:
    avg_aqi   = round(df_aq['pm25'].mean(), 1)
    avg_temp  = round(df_wx['temperature'].mean(), 1)
    total_rain= round(df_wx['rainfall'].sum(), 1)
    avg_hum   = int(df_wx['humidity'].mean())

    aqi_color  = "#f43f5e" if avg_aqi > 55 else "#f59e0b" if avg_aqi > 35 else "#34d399"
    aqi_status = "UNHEALTHY" if avg_aqi > 55 else "MODERATE" if avg_aqi > 35 else "GOOD"

    st.markdown(f"""
        <div class="kpi-container">
            <div class="kpi-card" style="border-color:{aqi_color}44;">
                <div class="kpi-value" style="color:{aqi_color};">{avg_aqi} µg/m³</div>
                <div class="kpi-label">Avg PM2.5 AQI</div>
                <div class="kpi-trend warn">{aqi_status}</div>
            </div>
            <div class="kpi-card amber">
                <div class="kpi-value amber">{avg_temp} °C</div>
                <div class="kpi-label">Avg Temperature</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-value cyan">{total_rain} mm</div>
                <div class="kpi-label">Cumulative Rainfall</div>
                <div class="kpi-trend up">Wash Effect Active</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-value">{avg_hum}%</div>
                <div class="kpi-label">Avg Humidity</div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="section-label">PM2.5 by Area</div>', unsafe_allow_html=True)
        df_area_aq = df_aq.groupby('area')['pm25'].mean().reset_index().sort_values('pm25', ascending=True)
        fig = px.bar(df_area_aq, x='pm25', y='area', orientation='h',
                     color='pm25', color_continuous_scale=[[0,'#1e3a5f'],[0.5,'#f59e0b'],[1,'#f43f5e']],
                     labels={'pm25':'PM2.5 (µg/m³)','area':'Zone'})
        fig.update_layout(**CHART_LAYOUT)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown('<div class="section-label">AQI vs Temperature Scatter</div>', unsafe_allow_html=True)
        df_aq_daily = df_aq.groupby('date')['pm25'].mean().reset_index()
        df_aq_daily['date'] = pd.to_datetime(df_aq_daily['date'])
        df_env = pd.merge(df_aq_daily, df_wx, on='date')
        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(
            x=df_env['temperature'], y=df_env['pm25'],
            mode='markers',
            marker=dict(size=df_env['humidity']/8, color=df_env['rainfall'],
                        colorscale='Teal', showscale=True,
                        colorbar=dict(title='Rainfall(mm)', tickfont=dict(family='Fira Code,monospace',color='#64748b',size=9)),
                        line=dict(color='#0f172a', width=1)),
            hovertemplate='<b>Temp: %{x}°C</b><br>PM2.5: %{y} µg/m³<extra></extra>'
        ))
        fig2.update_layout(**CHART_LAYOUT,
            xaxis_title='Temperature (°C)', yaxis_title='PM2.5 (µg/m³)')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown('<div class="section-label" style="margin-top:1rem;">Pollutant Distribution</div>', unsafe_allow_html=True)
    col3, col4 = st.columns([1,2])
    with col3:
        df_poll = df_aq[['pm25','pm10','no2','so2','o3']].mean().reset_index()
        df_poll.columns = ['Pollutant','Concentration']
        POLL_COLORS = ['#22d3ee','#f59e0b','#a855f7','#f43f5e','#34d399']
        fig3 = go.Figure(go.Pie(
            labels=df_poll['Pollutant'], values=df_poll['Concentration'],
            hole=0.5, marker_colors=POLL_COLORS,
            textfont=dict(family='Fira Code, monospace', size=10),
            hovertemplate='<b>%{label}</b>: %{value:.1f} µg/m³<extra></extra>'
        ))
        fig3.update_layout(**CHART_LAYOUT, showlegend=True)
        st.plotly_chart(fig3, use_container_width=True)

    with col4:
        st.markdown('<div class="section-label">Weather Trends</div>', unsafe_allow_html=True)
        fig4 = go.Figure()
        fig4.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['temperature'],
                       name='Temp (°C)', line=dict(color='#f43f5e', width=2)))
        fig4.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['rainfall'],
                       name='Rainfall (mm)', line=dict(color='#22d3ee', width=2),
                       fill='tozeroy', fillcolor='rgba(34,211,238,0.05)'))
        fig4.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['wind_speed'],
                       name='Wind (km/h)', line=dict(color='#a855f7', width=1.5, dash='dot')))
        fig4.update_layout(**CHART_LAYOUT)
        st.plotly_chart(fig4, use_container_width=True)

    # ─── IMD Climate Normals ─────────────────────────────────────────────────
    st.markdown('<div class="section-label" style="margin-top:2rem;">IMD Climate Normals // Coimbatore (1981–2010)</div>', unsafe_allow_html=True)
    try:
        df_normals = db.get_climate_normals()
        if not df_normals.empty:
            normals_month = df_normals['month'].str[:3].str.capitalize().tolist()
            col_n1, col_n2 = st.columns(2)
            with col_n1:
                st.markdown('<div class="section-label">Monthly Temperature Envelope</div>', unsafe_allow_html=True)
                fig_n1 = go.Figure()
                fig_n1.add_trace(go.Scatter(x=normals_month, y=df_normals['daily_max_temp'],
                                name='Max (°C)', mode='lines+markers',
                                line=dict(color='#f43f5e', width=2), marker=dict(size=6)))
                fig_n1.add_trace(go.Scatter(x=normals_month, y=df_normals['daily_min_temp'],
                                name='Min (°C)', mode='lines+markers',
                                line=dict(color='#22d3ee', width=2), marker=dict(size=6),
                                fill='tonexty', fillcolor='rgba(34,211,238,0.06)'))
                fig_n1.update_layout(**CHART_LAYOUT, xaxis_title='Month', yaxis_title='Temperature (°C)')
                st.plotly_chart(fig_n1, use_container_width=True)

            with col_n2:
                st.markdown('<div class="section-label">Mean Rainfall & Rainy Days</div>', unsafe_allow_html=True)
                fig_n2 = go.Figure()
                fig_n2.add_trace(go.Bar(x=normals_month, y=df_normals['mean_total_rainfall'],
                                name='Rainfall (mm)', marker_color='#22d3ee'))
                fig_n2.add_trace(go.Scatter(x=normals_month, y=df_normals['mean_rainy_days'],
                                name='Rainy Days', mode='lines+markers',
                                line=dict(color='#f59e0b', width=2), yaxis='y2'))
                fig_n2.update_layout(**CHART_LAYOUT,
                    yaxis=dict(title='Rainfall (mm)', gridcolor='#1e293b'),
                    yaxis2=dict(title='Rainy Days', overlaying='y', side='right',
                                gridcolor='rgba(0,0,0,0)', color='#94a3b8'))
                st.plotly_chart(fig_n2, use_container_width=True)
        else:
            st.info("Climate normals not loaded — run `python scripts/ingest_external_data.py`.")
    except Exception as e:
        st.warning(f"Climate normals unavailable: {e}")

    # ─── Historical Monthly AQI ─────────────────────────────────────────────
    st.markdown('<div class="section-label" style="margin-top:1rem;">Historical Monthly AQI // Real CPCB Observations</div>', unsafe_allow_html=True)
    try:
        df_hist = db.get_monthly_air_quality()
        if not df_hist.empty:
            df_hist['label'] = df_hist['month_year'].astype(str)
            col_h1, col_h2 = st.columns(2)
            with col_h1:
                fig_h1 = go.Figure()
                fig_h1.add_trace(go.Scatter(x=df_hist['label'], y=df_hist['pm25'],
                                name='PM2.5', mode='lines+markers',
                                line=dict(color='#f59e0b', width=2), marker=dict(size=6)))
                fig_h1.add_trace(go.Scatter(x=df_hist['label'], y=df_hist['pm10'],
                                name='PM10', mode='lines+markers',
                                line=dict(color='#f43f5e', width=2, dash='dot'), marker=dict(size=5)))
                fig_h1.update_layout(**CHART_LAYOUT, xaxis_title='Month-Year', yaxis_title='µg/m³')
                st.plotly_chart(fig_h1, use_container_width=True)

            with col_h2:
                st.markdown('<div class="section-label">Gaseous Pollutants</div>', unsafe_allow_html=True)
                fig_h2 = go.Figure()
                for col, color in [('no2', '#22d3ee'), ('so2', '#a855f7'), ('o3', '#34d399')]:
                    fig_h2.add_trace(go.Scatter(x=df_hist['label'], y=df_hist[col],
                                    name=col.upper(), mode='lines+markers',
                                    line=dict(color=color, width=1.8), marker=dict(size=5)))
                fig_h2.update_layout(**CHART_LAYOUT, xaxis_title='Month-Year', yaxis_title='µg/m³')
                st.plotly_chart(fig_h2, use_container_width=True)
        else:
            st.info("Historical AQI not loaded — run `python scripts/ingest_external_data.py`.")
    except Exception as e:
        st.warning(f"Historical AQI unavailable: {e}")

    # ─── April Extreme Weather ──────────────────────────────────────────────
    st.markdown('<div class="section-label" style="margin-top:1rem;">April Extreme Weather Archive // IMD</div>', unsafe_allow_html=True)
    try:
        df_ext = db.get_extreme_weather()
        if not df_ext.empty:
            fig_x = go.Figure()
            fig_x.add_trace(go.Scatter(x=df_ext['year'], y=df_ext['highest_max_temp'],
                            name='Highest Max Temp (°C)', mode='lines+markers',
                            line=dict(color='#f43f5e', width=2), marker=dict(size=7)))
            fig_x.add_trace(go.Scatter(x=df_ext['year'], y=df_ext['lowest_min_temp'],
                            name='Lowest Min Temp (°C)', mode='lines+markers',
                            line=dict(color='#22d3ee', width=2), marker=dict(size=7)))
            fig_x.update_layout(**CHART_LAYOUT, xaxis_title='Year', yaxis_title='Temperature (°C)')
            st.plotly_chart(fig_x, use_container_width=True)

            st.markdown('<div class="section-label">April Rainfall Extremes (mm)</div>', unsafe_allow_html=True)
            fig_x2 = px.bar(df_ext, x='year', y='rainfall_monthly_total',
                            color='rainfall_monthly_total',
                            color_continuous_scale=[[0, '#0f172a'], [0.5, '#3b82f6'], [1, '#22d3ee']],
                            labels={'rainfall_monthly_total': 'Monthly Total (mm)', 'year': 'Year'})
            fig_x2.update_layout(**CHART_LAYOUT)
            st.plotly_chart(fig_x2, use_container_width=True)
        else:
            st.info("Extreme weather archive not loaded — run `python scripts/ingest_external_data.py`.")
    except Exception as e:
        st.warning(f"Extreme weather archive unavailable: {e}")

sy.footer()