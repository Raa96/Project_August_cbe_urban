import streamlit as st
import pandas as pd
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db
import styles as sy

st.set_page_config(page_title="Data Explorer — CUI", layout="wide")
sy.inject_custom_css()
sy.page_header(
    "Data Explorer",
    "> Direct schema access and raw tabular export for external modeling.",
    "DATA MODULE // ACTIVE",
)
sy.ticker([
    "> SQLite connector active.",
    "> Schema ready for extraction.",
    "> All raw tables initialized.",
])

st.markdown('<p style="font-family:\'Fira Code\',monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#64748b;margin-bottom:8px;">// Database Selection</p>', unsafe_allow_html=True)
dataset_map = {
    "Areas (Wards/Zones)": db.get_areas,
    "Traffic Data": db.get_traffic,
    "Air Quality & Environment": db.get_air_quality,
    "Weather Data": db.get_weather,
    "Civic Issues": db.get_civic_issues,
    "Commercial Activity": db.get_commercial_activity,
    "IMD Climate Normals (1981-2010)": db.get_climate_normals,
    "April Extreme Weather (IMD)": db.get_extreme_weather,
    "Historical Monthly AQI (CPCB)": db.get_monthly_air_quality,
    "OSM Infrastructure (OpenStreetMap)": db.get_osm_infrastructure,
}

selected_dataset = st.selectbox("Select Table Schema", list(dataset_map.keys()))
df = dataset_map[selected_dataset]()

col1, col2 = st.columns(2)
with col1:
    st.markdown(f"""
        <div class="kpi-card" style="margin-bottom:20px;">
            <div class="kpi-value cyan">{len(df):,}</div>
            <div class="kpi-label">Total Rows</div>
        </div>
    """, unsafe_allow_html=True)
with col2:
    st.markdown(f"""
        <div class="kpi-card" style="margin-bottom:20px;">
            <div class="kpi-value amber">{len(df.columns)}</div>
            <div class="kpi-label">Vector Columns</div>
        </div>
    """, unsafe_allow_html=True)

st.markdown('<div class="section-label">Raw Data Preview</div>', unsafe_allow_html=True)
st.dataframe(df, use_container_width=True, hide_index=True)

csv = df.to_csv(index=False).encode('utf-8')
st.download_button(
    label="EXPORT CSV",
    data=csv,
    file_name=f"{selected_dataset.replace(' ', '_').lower()}.csv",
    mime='text/csv'
)

st.markdown('<div class="section-label" style="margin-top:2rem;">Data Types & Schema Integrity</div>', unsafe_allow_html=True)
dtypes = df.dtypes.astype(str).reset_index()
dtypes.columns = ['Column', 'Data Type (Pandas)']
st.dataframe(dtypes, use_container_width=True, hide_index=True)

sy.footer()