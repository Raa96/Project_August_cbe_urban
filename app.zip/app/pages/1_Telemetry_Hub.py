import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db
import styles as sy

st.set_page_config(page_title="Telemetry Hub — CUI", layout="wide")
sy.inject_custom_css()
sy.page_header("Telemetry Hub", "> Traffic volume telemetry, weather vectors, and zone benchmarking across Coimbatore.", "TELEMETRY MODULE // ACTIVE")
sy.ticker(["> Connecting telemetry streams...", "> Traffic matrix loaded.", "> Weather vectors synced.", "> Zone benchmarks computed."])

CHART_LAYOUT = dict(
    paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(2,6,23,0.6)',
    font=dict(family='Fira Code, monospace', color='#94a3b8', size=11),
    margin=dict(l=12, r=12, t=36, b=12),
    xaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    yaxis=dict(gridcolor='#1e293b', linecolor='#1e293b', zerolinecolor='#1e293b'),
    legend=dict(bgcolor='rgba(15,23,42,0.6)', bordercolor='#334155', borderwidth=1),
)

tab_traffic, tab_weather, tab_zones = st.tabs(
    ["Traffic & Congestion", "Weather Telemetry", "Zone Benchmarking"]
)

# ═══════════════════════════════════════════════════════════════════════════════
# TRAFFIC & CONGESTION
# ═══════════════════════════════════════════════════════════════════════════════
with tab_traffic:
    areas_list = ["All"] + list(db.get_areas()['area'].unique())
    st.sidebar.markdown('<p style="font-family:\'Fira Code\',monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#64748b;margin-bottom:8px;">// Traffic Filter</p>', unsafe_allow_html=True)
    selected_area = st.sidebar.selectbox("Traffic Area Node", areas_list)

    area_filter = None if selected_area == "All" else selected_area
    df = db.get_traffic(area=area_filter)

    if df.empty:
        st.warning("No traffic records found.")
    else:
        avg_traffic    = int(df['vehicle_count'].mean())
        peak_record    = df.loc[df['vehicle_count'].idxmax()]
        total_vehicles = int(df['vehicle_count'].sum())

        st.markdown(f"""
            <div class="kpi-container">
                <div class="kpi-card amber">
                    <div class="kpi-value amber">{avg_traffic:,}</div>
                    <div class="kpi-label">Avg Traffic / hr</div>
                    <div class="kpi-trend warn">Across All Slots</div>
                </div>
                <div class="kpi-card rose">
                    <div class="kpi-value rose" style="font-size:1.4rem;margin-top:4px;">{peak_record['area']}</div>
                    <div class="kpi-label">Peak Congestion Node</div>
                    <div class="kpi-trend critical">MAX DENSITY</div>
                </div>
                <div class="kpi-card amber">
                    <div class="kpi-value amber">{peak_record['time']}</div>
                    <div class="kpi-label">Peak Commute Time</div>
                    <div class="kpi-trend warn">Recurring Daily</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">{total_vehicles:,}</div>
                    <div class="kpi-label">Cumulative Vehicles</div>
                    <div class="kpi-trend up">Logged in Period</div>
                </div>
            </div>
        """, unsafe_allow_html=True)

        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="section-label">Avg Volume by Area</div>', unsafe_allow_html=True)
            df_area_avg = df.groupby('area')['vehicle_count'].mean().reset_index().sort_values('vehicle_count', ascending=True)
            fig = px.bar(df_area_avg, x='vehicle_count', y='area', orientation='h',
                         color='vehicle_count', color_continuous_scale=[[0,'#1e3a5f'],[0.5,'#f59e0b'],[1,'#f43f5e']],
                         labels={'vehicle_count':'Avg Vehicle Count','area':'Junction'})
            fig.update_layout(**CHART_LAYOUT)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            st.markdown('<div class="section-label">Congestion by Time Slot</div>', unsafe_allow_html=True)
            time_order = {"08:30 AM": 1, "02:00 PM": 2, "06:30 PM": 3}
            df_time_avg = df.groupby('time')['vehicle_count'].mean().reset_index()
            df_time_avg['order'] = df_time_avg['time'].map(time_order)
            df_time_avg = df_time_avg.sort_values('order')
            fig2 = go.Figure()
            fig2.add_trace(go.Scatter(
                x=df_time_avg['time'], y=df_time_avg['vehicle_count'],
                mode='lines+markers',
                line=dict(color='#22d3ee', width=3, shape='spline'),
                marker=dict(size=10, color='#0f172a', line=dict(color='#22d3ee', width=2)),
                fill='tozeroy', fillcolor='rgba(34,211,238,0.06)',
                name='Avg Vehicles'
            ))
            fig2.update_layout(**CHART_LAYOUT)
            st.plotly_chart(fig2, use_container_width=True)

        st.markdown('<div class="section-label" style="margin-top:1rem;">Vehicle Class Breakdown by Junction</div>', unsafe_allow_html=True)
        df_veh = df.groupby('area')[['cars','bikes','buses','autos','trucks']].mean().reset_index()
        df_melted = df_veh.melt(id_vars='area', var_name='Vehicle Type', value_name='Avg Count')
        COLORS = ['#22d3ee','#f59e0b','#a855f7','#f43f5e','#34d399']
        fig3 = px.bar(df_melted, x='area', y='Avg Count', color='Vehicle Type',
                      barmode='stack', color_discrete_sequence=COLORS,
                      labels={'Avg Count':'Avg Vehicles','area':'Junction'})
        fig3.update_layout(**CHART_LAYOUT, xaxis_tickangle=-35)
        st.plotly_chart(fig3, use_container_width=True)

        st.markdown('<div class="section-label" style="margin-top:1rem;">Traffic Trend Over Time</div>', unsafe_allow_html=True)
        df_trend = df.groupby('date')['vehicle_count'].mean().reset_index()
        df_trend['date'] = pd.to_datetime(df_trend['date'])
        fig4 = go.Figure()
        fig4.add_trace(go.Scatter(
            x=df_trend['date'], y=df_trend['vehicle_count'],
            mode='lines', line=dict(color='#22d3ee', width=2),
            fill='tozeroy', fillcolor='rgba(34,211,238,0.05)', name='Daily Avg'
        ))
        fig4.update_layout(**CHART_LAYOUT)
        st.plotly_chart(fig4, use_container_width=True)

# ═══════════════════════════════════════════════════════════════════════════════
# WEATHER TELEMETRY
# ═══════════════════════════════════════════════════════════════════════════════
with tab_weather:
    df_wx = db.get_weather()
    df_wx['date'] = pd.to_datetime(df_wx['date'])

    if df_wx.empty:
        st.warning("No weather telemetry found.")
    else:
        avg_temp  = round(df_wx['temperature'].mean(), 1)
        total_rain= round(df_wx['rainfall'].sum(), 1)
        avg_hum   = int(df_wx['humidity'].mean())
        avg_wind  = round(df_wx['wind_speed'].mean(), 1)

        st.markdown(f"""
            <div class="kpi-container">
                <div class="kpi-card amber">
                    <div class="kpi-value amber">{avg_temp} °C</div>
                    <div class="kpi-label">Avg Temperature</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value cyan">{total_rain} mm</div>
                    <div class="kpi-label">Cumulative Rainfall</div>
                    <div class="kpi-trend up">Wash Effect Active</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">{avg_hum}%</div>
                    <div class="kpi-label">Avg Humidity</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value violet">{avg_wind} km/h</div>
                    <div class="kpi-label">Avg Wind Speed</div>
                </div>
            </div>
        """, unsafe_allow_html=True)

        st.markdown('<div class="section-label">Weather Trends</div>', unsafe_allow_html=True)
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['temperature'],
                       name='Temp (°C)', line=dict(color='#f43f5e', width=2)))
        fig.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['rainfall'],
                       name='Rainfall (mm)', line=dict(color='#22d3ee', width=2),
                       fill='tozeroy', fillcolor='rgba(34,211,238,0.05)'))
        fig.add_trace(go.Scatter(x=df_wx['date'], y=df_wx['wind_speed'],
                       name='Wind (km/h)', line=dict(color='#a855f7', width=1.5, dash='dot')))
        fig.update_layout(**CHART_LAYOUT)
        st.plotly_chart(fig, use_container_width=True)

# ═══════════════════════════════════════════════════════════════════════════════
# ZONE BENCHMARKING
# ═══════════════════════════════════════════════════════════════════════════════
with tab_zones:
    df_areas = db.get_areas()
    zones = list(df_areas['zone'].unique())

    st.sidebar.markdown('<p style="font-family:\'Fira Code\',monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#64748b;margin-bottom:8px;">// Zone Vectors</p>', unsafe_allow_html=True)
    zone_a = st.sidebar.selectbox("Zone A", zones, index=0)
    zone_b = st.sidebar.selectbox("Zone B", zones, index=1 if len(zones) > 1 else 0)

    if zone_a == zone_b:
        st.warning("Select two distinct zones for benchmarking.")
    else:
        df_traffic = db.get_traffic()
        df_aq = db.get_air_quality()
        df_civic = db.get_civic_issues()

        traffic_a = df_traffic[df_traffic['area'].isin(df_areas[df_areas['zone']==zone_a]['area'])]['vehicle_count'].mean()
        traffic_b = df_traffic[df_traffic['area'].isin(df_areas[df_areas['zone']==zone_b]['area'])]['vehicle_count'].mean()
        aqi_a = df_aq[df_aq['area'].isin(df_areas[df_areas['zone']==zone_a]['area'])]['pm25'].mean()
        aqi_b = df_aq[df_aq['area'].isin(df_areas[df_areas['zone']==zone_b]['area'])]['pm25'].mean()
        civic_a = len(df_civic[df_civic['area'].isin(df_areas[df_areas['zone']==zone_a]['area'])])
        civic_b = len(df_civic[df_civic['area'].isin(df_areas[df_areas['zone']==zone_b]['area'])])

        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f'<div class="section-label" style="font-size:14px;color:#22d3ee;">Zone A // {zone_a}</div>', unsafe_allow_html=True)
            st.markdown(f"""
                <div class="kpi-card" style="margin-bottom:12px;">
                    <div class="kpi-value cyan">{int(traffic_a):,}</div>
                    <div class="kpi-label">Avg Vehicle Flow</div>
                </div>
                <div class="kpi-card" style="margin-bottom:12px;">
                    <div class="kpi-value amber">{round(aqi_a,1)}</div>
                    <div class="kpi-label">PM2.5 Concentration</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value rose">{civic_a}</div>
                    <div class="kpi-label">Total Grievances</div>
                </div>
            """, unsafe_allow_html=True)

        with col2:
            st.markdown(f'<div class="section-label" style="font-size:14px;color:#a855f7;">Zone B // {zone_b}</div>', unsafe_allow_html=True)
            st.markdown(f"""
                <div class="kpi-card" style="margin-bottom:12px;border-color:rgba(168,85,247,0.3);">
                    <div class="kpi-value" style="color:#a855f7;">{int(traffic_b):,}</div>
                    <div class="kpi-label">Avg Vehicle Flow</div>
                </div>
                <div class="kpi-card" style="margin-bottom:12px;border-color:rgba(168,85,247,0.3);">
                    <div class="kpi-value" style="color:#a855f7;">{round(aqi_b,1)}</div>
                    <div class="kpi-label">PM2.5 Concentration</div>
                </div>
                <div class="kpi-card" style="border-color:rgba(168,85,247,0.3);">
                    <div class="kpi-value" style="color:#a855f7;">{civic_b}</div>
                    <div class="kpi-label">Total Grievances</div>
                </div>
            """, unsafe_allow_html=True)

        st.markdown('<div class="section-label" style="margin-top:2rem;">Radar Matrix // Relative Benchmarking</div>', unsafe_allow_html=True)
        max_traf = max(traffic_a, traffic_b, 1)
        max_aqi  = max(aqi_a, aqi_b, 1)
        max_civ  = max(civic_a, civic_b, 1)

        fig = go.Figure()
        fig.add_trace(go.Scatterpolar(
            r=[traffic_a/max_traf, aqi_a/max_aqi, civic_a/max_civ],
            theta=['Traffic Flow', 'PM2.5 Level', 'Civic Issues'],
            fill='toself', name=zone_a,
            line=dict(color='#22d3ee'), fillcolor='rgba(34,211,238,0.2)'
        ))
        fig.add_trace(go.Scatterpolar(
            r=[traffic_b/max_traf, aqi_b/max_aqi, civic_b/max_civ],
            theta=['Traffic Flow', 'PM2.5 Level', 'Civic Issues'],
            fill='toself', name=zone_b,
            line=dict(color='#a855f7'), fillcolor='rgba(168,85,247,0.2)'
        ))
        fig.update_layout(
            polar=dict(
                bgcolor='rgba(15,23,42,0.6)',
                radialaxis=dict(visible=False, range=[0, 1.1]),
                angularaxis=dict(tickfont=dict(family='Fira Code, monospace', color='#cbd5e1', size=11))
            ),
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family='Fira Code, monospace', color='#94a3b8'),
            legend=dict(bgcolor='rgba(15,23,42,0.6)', bordercolor='#334155', borderwidth=1),
            margin=dict(t=20, b=20)
        )
        st.plotly_chart(fig, use_container_width=True)

sy.footer()