import streamlit as st
import pandas as pd
import numpy as np
import sys, os, re

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db
import styles as sy

st.set_page_config(page_title="Vector Search — CUI", layout="wide")
sy.inject_custom_css()
sy.page_header(
    "Vector Semantic Search",
    "> TF-IDF vectorized retrieval across all dataset tables — telemetry, POIs, civic, climatology.",
    "SEARCH MODULE // ACTIVE",
)
sy.ticker([
    "> Building TF-IDF index...",
    "> 1300+ vectors embedded.",
    "> Cosine similarity engine ready.",
    "> Semantic retrieval online.",
])


@st.cache_data(show_spinner=False)
def build_documents():
    """Flatten every dataset table into searchable text documents."""
    docs = []

    # Areas
    try:
        df = db.get_areas()
        for _, r in df.iterrows():
            docs.append({
                "source": "Areas / Wards",
                "title": r["area"],
                "text": f"{r['area']} {r['area_type']} {r['zone']} zone ward {r['ward']} "
                        f"coordinates {r['latitude']} {r['longitude']}",
            })
    except Exception:
        pass

    # Traffic
    try:
        df = db.get_traffic()
        for _, r in df.iterrows():
            docs.append({
                "source": "Traffic",
                "title": f"{r['area']} · {r['time']}",
                "text": f"traffic {r['area']} {r['date']} {r['time']} {r['vehicle_count']} vehicles "
                        f"{r['cars']} cars {r['bikes']} bikes {r['buses']} buses {r['autos']} autos {r['trucks']} trucks",
            })
    except Exception:
        pass

    # Air quality
    try:
        df = db.get_air_quality()
        for _, r in df.iterrows():
            docs.append({
                "source": "Air Quality",
                "title": f"{r['area']} · {r['date']}",
                "text": f"air quality aqi {r['area']} station {r['station']} {r['date']} "
                        f"pm2.5 {r['pm25']} pm10 {r['pm10']} no2 {r['no2']} so2 {r['so2']} o3 {r['o3']}",
            })
    except Exception:
        pass

    # Weather
    try:
        df = db.get_weather()
        for _, r in df.iterrows():
            docs.append({
                "source": "Weather",
                "title": f"Weather · {r['date']}",
                "text": f"weather {r['date']} temperature {r['temperature']} humidity {r['humidity']} "
                        f"rainfall {r['rainfall']} wind {r['wind_speed']}",
            })
    except Exception:
        pass

    # Civic issues
    try:
        df = db.get_civic_issues()
        for _, r in df.iterrows():
            docs.append({
                "source": "Civic Issues",
                "title": f"{r['area']} · {r['issue_type']}",
                "text": f"civic issue complaint {r['area']} {r['issue_type']} severity {r['severity']} "
                        f"status {r['status']} resolution {r['resolution_days']} days",
            })
    except Exception:
        pass

    # Commercial activity
    try:
        df = db.get_commercial_activity()
        for _, r in df.iterrows():
            docs.append({
                "source": "Commercial",
                "title": f"{r['area']} · {r['commercial_category']}",
                "text": f"commercial business {r['area']} {r['commercial_category']} "
                        f"{r['business_count']} businesses footfall {r['estimated_footfall']}",
            })
    except Exception:
        pass

    # Climate normals
    try:
        df = db.get_climate_normals()
        for _, r in df.iterrows():
            docs.append({
                "source": "Climate Normals (IMD)",
                "title": f"{r['month']} Normals",
                "text": f"climate normal {r['month']} min temp {r['daily_min_temp']} max temp {r['daily_max_temp']} "
                        f"rainfall {r['mean_total_rainfall']} rainy days {r['mean_rainy_days']} "
                        f"hail {r['mean_hail_days']} thunder {r['mean_thunder_days']} fog {r['mean_fog_days']}",
            })
    except Exception:
        pass

    # Extreme weather
    try:
        df = db.get_extreme_weather()
        for _, r in df.iterrows():
            docs.append({
                "source": "Extreme Weather (IMD)",
                "title": f"April {r['year']}",
                "text": f"extreme weather april {r['year']} highest temp {r['highest_max_temp']} "
                        f"lowest temp {r['lowest_min_temp']} rainfall {r['rainfall_monthly_total']}",
            })
    except Exception:
        pass

    # Monthly air quality
    try:
        df = db.get_monthly_air_quality()
        for _, r in df.iterrows():
            docs.append({
                "source": "Monthly AQI (CPCB)",
                "title": f"{r['month_year']}",
                "text": f"monthly aqi {r['city']} {r['month_year']} pm2.5 {r['pm25']} pm10 {r['pm10']} "
                        f"no2 {r['no2']} so2 {r['so2']} o3 {r['o3']}",
            })
    except Exception:
        pass

    # OSM infrastructure
    try:
        df = db.get_osm_infrastructure()
        for _, r in df.iterrows():
            docs.append({
                "source": "OSM Infrastructure",
                "title": r["name"],
                "text": f"{r['category']} {r['name']} near {r['area']} distance {r['distance_to_area_km']} km "
                        f"coordinates {r['lat']} {r['lon']}",
            })
    except Exception:
        pass

    return pd.DataFrame(docs)


def tokenize(text: str):
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    return tokens


def tokenize(text: str):
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    return tokens


@st.cache_resource(show_spinner=False)
def build_tfidf(doc_texts):
    """Build a TF-IDF vectorizer + matrix with pure numpy/scipy."""
    from sklearn.feature_extraction.text import TfidfVectorizer
    vectorizer = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        min_df=1,
        sublinear_tf=True,
    )
    matrix = vectorizer.fit_transform(doc_texts)
    return vectorizer, matrix


df_docs = build_documents()
vectorizer, matrix = build_tfidf(df_docs["text"].tolist())

# ─── Stats ─────────────────────────────────────────────────────────────────────
source_counts = df_docs["source"].value_counts()

st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-card">
            <div class="kpi-value cyan">{len(df_docs):,}</div>
            <div class="kpi-label">Indexed Vectors</div>
            <div class="kpi-trend up">Full Dataset</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-value violet">{len(source_counts):}</div>
            <div class="kpi-label">Dataset Sources</div>
        </div>
        <div class="kpi-card lime">
            <div class="kpi-value lime">{matrix.shape[1]:,}</div>
            <div class="kpi-label">Feature Dimension</div>
            <div class="kpi-trend up text-lime">TF-IDF Space</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-value">{source_counts.get('OSM Infrastructure', 0):,}</div>
            <div class="kpi-label">POI Vectors</div>
        </div>
    </div>
""", unsafe_allow_html=True)

# ─── Search UI ─────────────────────────────────────────────────────────────────
st.markdown('<div class="section-label">Semantic Query</div>', unsafe_allow_html=True)
col_q, col_n = st.columns([3, 1])
with col_q:
    query = st.text_input("Search query", placeholder="e.g. hospitals near Gandhipuram, high pm2.5 areas, rainfall in april...", label_visibility="collapsed")
with col_n:
    top_k = st.selectbox("Results", [5, 10, 15, 20], index=1)

if query.strip():
    q_vec = vectorizer.transform([query])
    from sklearn.metrics.pairwise import cosine_similarity
    scores = cosine_similarity(q_vec, matrix).ravel()
    top_idx = np.argsort(scores)[::-1][:top_k]

    st.markdown('<div class="section-label" style="margin-top:1rem;">Ranked Matches</div>', unsafe_allow_html=True)
    for rank, i in enumerate(top_idx, 1):
        score = scores[i]
        if score < 0.01:
            continue
        row = df_docs.iloc[i]
        st.markdown(f"""
            <div class="info-card" style="border-left:3px solid #22d3ee;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <h4 style="color:#22d3ee;">{rank:02d} // {row['title']}</h4>
                    <span class="kpi-trend up">SIM {score:.3f}</span>
                </div>
                <p style="color:#64748b;font-family:'Fira Code',monospace;font-size:10px;text-transform:uppercase;margin-bottom:6px;">{row['source']}</p>
                <p>{row['text'][:200]}{'…' if len(row['text']) > 200 else ''}</p>
            </div>
        """, unsafe_allow_html=True)
else:
    st.markdown("""
        <div class="info-card">
            <h4 style="color:#f59e0b;">Try a query</h4>
            <p>Search naturally across every dataset table. Examples:<br>
            &nbsp;&nbsp;• hospitals near Gandhipuram<br>
            &nbsp;&nbsp;• traffic congestion at 06:30 pm<br>
            &nbsp;&nbsp;• highest rainfall in april<br>
            &nbsp;&nbsp;• parks and green space</p>
        </div>
    """, unsafe_allow_html=True)

# ─── Corpus breakdown ──────────────────────────────────────────────────────────
st.markdown('<div class="section-label" style="margin-top:2rem;">Indexed Corpus // By Source</div>', unsafe_allow_html=True)
st.dataframe(
    source_counts.reset_index().rename(columns={"index": "Dataset Source", "source": "Vector Count"}),
    use_container_width=True, hide_index=True,
)

sy.footer()